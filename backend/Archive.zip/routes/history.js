const express = require("express");

const router = express.Router();

router.get("/get", async (req, res) => {

});

module.exports = router;